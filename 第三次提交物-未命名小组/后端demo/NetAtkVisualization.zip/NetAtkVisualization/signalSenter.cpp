﻿#include "signalSenter.h"

SignalSenter* signalSenter = new SignalSenter();

SignalSenter::SignalSenter(QObject *parent) : QObject(parent)
{

}
